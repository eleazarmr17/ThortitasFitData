import { env } from "cloudflare:workers";
import { getChatGPTUser, type ChatGPTUser } from "../app/chatgpt-auth";
import { ApiError, numeric, object, text, validateProfile, validateRecord, type JsonRecord } from "./server-validation";

const TABLES = { routine: "routines", session: "sessions", step: "daily_steps", weight: "body_weights", goal: "goals", challenge: "challenges", post: "posts" } as const;
type Entity = keyof typeof TABLES;
type OwnedRow = { id: string; user_id: string; data: string; created_at: string; updated_at: string };
type UserRow = { id: string; name: string; email: string; profile: string; created_at: string };
const now = () => new Date().toISOString();
export function database(): D1Database {
  if (!env.DB) throw new ApiError("Data storage is temporarily unavailable. Please try again shortly.", 503);
  return env.DB;
}
function parse(value: string): JsonRecord { try { return object(JSON.parse(value)); } catch { return {}; } }
function unpack(row: OwnedRow): JsonRecord { return { ...parse(row.data), id: row.id, userId: row.user_id, createdAt: row.created_at, updatedAt: row.updated_at }; }
function profile(row: UserRow): JsonRecord { return { weeklyTarget: 4, stepTarget: 10000, ...parse(row.profile) }; }
export async function authenticated(): Promise<ChatGPTUser> {
  const user = await getChatGPTUser();
  if (!user) throw new ApiError("Sign in with ChatGPT to access your private fitness data.", 401);
  return user;
}
export function checkWriteOrigin(request: Request) {
  const origin = request.headers.get("origin");
  if ((origin && origin !== new URL(request.url).origin) || request.headers.get("sec-fetch-site") === "cross-site") throw new ApiError("This request must come from your fitness app.", 403);
}
export async function boundedBody(request: Request, maxBytes: number): Promise<Uint8Array<ArrayBuffer>> {
  if (Number(request.headers.get("content-length") || 0) > maxBytes) throw new ApiError("This upload or record is too large.", 413);
  const reader = request.body?.getReader();
  if (!reader) return new Uint8Array();
  const chunks: Uint8Array[] = []; let size = 0;
  while (true) {
    const chunk = await reader.read(); if (chunk.done) break;
    size += chunk.value.byteLength;
    if (size > maxBytes) { await reader.cancel(); throw new ApiError("This upload or record is too large.", 413); }
    chunks.push(chunk.value);
  }
  const result = new Uint8Array(size); let offset = 0;
  for (const chunk of chunks) { result.set(chunk, offset); offset += chunk.byteLength; }
  return result;
}
export async function ensureUser(user: ChatGPTUser): Promise<UserRow> {
  const db = database();
  let row = await db.prepare("SELECT * FROM users WHERE id = ?").bind(user.userId).first<UserRow>();
  if (!row) {
    const timestamp = now();
    const statements = [db.prepare("INSERT OR IGNORE INTO users (id,name,email,profile,created_at) VALUES (?,?,?,?,?)").bind(user.userId, user.displayName, user.email, JSON.stringify({ weeklyTarget: 4, stepTarget: 10000 }), timestamp)];
    for (const name of ["Upper Body 1", "Lower Body 1", "Upper Body 2", "Lower Body 2"]) {
      statements.push(db.prepare("INSERT OR IGNORE INTO routines (id,user_id,data,created_at,updated_at) VALUES (?,?,?,?,?)").bind(`initial:${user.userId}:${name.replaceAll(" ", "-")}`, user.userId, JSON.stringify({ name, category: name, notes: "", exercises: [] }), timestamp, timestamp));
    }
    await db.batch(statements);
    row = await db.prepare("SELECT * FROM users WHERE id = ?").bind(user.userId).first<UserRow>();
  }
  if (!row) throw new ApiError("Your profile could not be loaded.", 503);
  return row;
}
export async function partnerId(userId: string): Promise<string | null> {
  const result = await database().prepare("SELECT other.user_id AS id FROM partner_members mine JOIN partner_members other ON mine.pair_id=other.pair_id AND mine.user_id<>other.user_id WHERE mine.user_id=? LIMIT 1").bind(userId).first<{ id: string }>();
  return result?.id ?? null;
}
export async function allowedIds(userId: string): Promise<string[]> {
  const partner = await partnerId(userId); return partner ? [userId, partner] : [userId];
}
function placeholders(values: unknown[]) { return values.map(() => "?").join(","); }
export async function snapshot(user: ChatGPTUser): Promise<JsonRecord> {
  const me = await ensureUser(user);
  const ids = await allowedIds(user.userId);
  const db = database(); const marks = placeholders(ids);
  const tableEntries = Object.entries(TABLES);
  const statements = tableEntries.map(([, table]) => db.prepare(`SELECT * FROM ${table} WHERE user_id IN (${marks}) ORDER BY created_at DESC`).bind(...ids));
  statements.push(db.prepare(`SELECT l.* FROM post_likes l JOIN posts p ON p.id=l.post_id WHERE p.user_id IN (${marks}) AND l.user_id IN (${marks})`).bind(...ids, ...ids));
  statements.push(db.prepare(`SELECT c.*,u.name,u.profile FROM post_comments c JOIN posts p ON p.id=c.post_id JOIN users u ON u.id=c.user_id WHERE p.user_id IN (${marks}) AND c.user_id IN (${marks}) ORDER BY c.created_at ASC`).bind(...ids, ...ids));
  statements.push(db.prepare("SELECT * FROM favorites WHERE user_id=?").bind(user.userId));
  statements.push(db.prepare("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 100").bind(user.userId));
  const results = await db.batch(statements);
  const result: JsonRecord = {};
  const outputNames: Record<Entity, string> = { routine: "routines", session: "sessions", step: "steps", weight: "weights", goal: "goals", challenge: "challenges", post: "posts" };
  tableEntries.forEach(([entity], i) => { result[outputNames[entity as Entity]] = (results[i].results as OwnedRow[]).map(unpack); });
  const likes = results[7].results as { post_id: string; user_id: string }[];
  const comments = results[8].results as { id: string; post_id: string; user_id: string; text: string; created_at: string; name: string; profile: string }[];
  result.posts = result.posts.map((post: JsonRecord) => ({ ...post, likes: likes.filter(l => l.post_id === post.id).map(l => l.user_id), comments: comments.filter(c => c.post_id === post.id).map(c => ({ id: c.id, userId: c.user_id, name: parse(c.profile).displayName || c.name, text: c.text, createdAt: c.created_at })) }));
  result.meals = result.posts.filter((post: JsonRecord) => post.type === "meal");
  result.favorites = (results[9].results as { id: string; kind: string; target_id: string }[]).map(row => ({ id: row.id, userId: user.userId, kind: row.kind, targetId: row.target_id }));
  result.notifications = (results[10].results as { id: string; text: string; read: number; created_at: string }[]).map(row => ({ id: row.id, text: row.text, read: !!row.read, createdAt: row.created_at }));
  result.profile = profile(me);
  result.user = { id: me.id, name: result.profile.displayName || me.name, email: me.email, profile: result.profile };
  const other = ids.length === 2 ? await db.prepare("SELECT * FROM users WHERE id=?").bind(ids[1]).first<UserRow>() : null;
  result.partner = other ? { id: other.id, name: profile(other).displayName || other.name, profile: profile(other) } : null;
  return result;
}
function entityName(value: unknown): Entity {
  if (typeof value !== "string" || !Object.hasOwn(TABLES, value)) throw new ApiError("Unknown record type.");
  return value as Entity;
}
async function ownRecord(table: string, id: string, userId: string): Promise<OwnedRow | null> {
  const row = await database().prepare(`SELECT * FROM ${table} WHERE id=?`).bind(id).first<OwnedRow>();
  if (row && row.user_id !== userId) throw new ApiError("You can only change your own records.", 403);
  return row;
}
async function readablePost(postId: string, userId: string): Promise<OwnedRow> {
  const row = await database().prepare("SELECT * FROM posts WHERE id=?").bind(postId).first<OwnedRow>();
  const ids = await allowedIds(userId);
  if (!row || !ids.includes(row.user_id)) throw new ApiError("That post is unavailable.", 404);
  return row;
}
async function validatePhotoOwner(url: unknown, userId: string) {
  if (!url) return;
  const key = new URL(String(url), "https://fitness.local").searchParams.get("key");
  const row = await database().prepare("SELECT user_id FROM media WHERE key=?").bind(key).first<{ user_id: string }>();
  if (!row || row.user_id !== userId) throw new ApiError("Choose one of your own uploaded photos.", 403);
}
async function notify(userId: string, message: string) {
  await database().prepare('INSERT INTO notifications (id,user_id,text,"read",created_at) VALUES (?,?,?,0,?)').bind(crypto.randomUUID(), userId, message, now()).run();
}
async function hashCode(code: string) {
  const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(code));
  return [...new Uint8Array(bytes)].map(byte => byte.toString(16).padStart(2, "0")).join("");
}
async function createPairCode(user: ChatGPTUser) {
  const db = database();
  if (await partnerId(user.userId)) throw new ApiError("You already have a linked partner.", 409);
  const membership = await db.prepare("SELECT pair_id,slot FROM partner_members WHERE user_id=?").bind(user.userId).first<{ pair_id: string; slot: number }>();
  const pairId = membership?.pair_id || crypto.randomUUID();
  const random = crypto.getRandomValues(new Uint8Array(12));
  const code = [...random].map(byte => byte.toString(16).padStart(2, "0")).join("").toUpperCase();
  const expiresAt = Date.now() + 7 * 86400000;
  const statements = [];
  if (!membership) statements.push(db.prepare("INSERT INTO partner_members (user_id,pair_id,slot) VALUES (?,?,0)").bind(user.userId, pairId));
  statements.push(db.prepare("DELETE FROM partner_invites WHERE inviter_id=?").bind(user.userId));
  statements.push(db.prepare("INSERT INTO partner_invites (code_hash,pair_id,inviter_id,expires_at) VALUES (?,?,?,?)").bind(await hashCode(code), pairId, user.userId, expiresAt));
  await db.batch(statements);
  return { code: code.match(/.{1,6}/g)!.join("-"), expiresAt: new Date(expiresAt).toISOString() };
}
async function joinPair(user: ChatGPTUser, value: unknown) {
  const code = text(value, "Invitation code", 100, true).replace(/[-\s]/g, "").toUpperCase();
  if (!/^[A-F0-9]{24}$/.test(code)) throw new ApiError("This invitation code is invalid.");
  const db = database();
  if (await partnerId(user.userId)) throw new ApiError("You already have a linked partner.", 409);
  const codeHash = await hashCode(code);
  const invite = await db.prepare("SELECT * FROM partner_invites WHERE code_hash=? AND expires_at>?").bind(codeHash, Date.now()).first<{ pair_id: string; inviter_id: string }>();
  if (!invite || invite.inviter_id === user.userId) throw new ApiError("That invitation is invalid or has expired.");
  const own = await db.prepare("SELECT * FROM partner_members WHERE user_id=?").bind(user.userId).first<{ pair_id: string }>();
  // Every user occupies one primary-keyed membership; the pair/slot index admits exactly two people.
  const statements = [];
  if (own) {
    statements.push(db.prepare("DELETE FROM partner_invites WHERE inviter_id=?").bind(user.userId));
    statements.push(db.prepare("DELETE FROM partner_members WHERE user_id=? AND pair_id=? AND NOT EXISTS (SELECT 1 FROM partner_members WHERE pair_id=? AND user_id<>?)").bind(user.userId, own.pair_id, own.pair_id, user.userId));
  }
  statements.push(db.prepare("INSERT INTO partner_members (user_id,pair_id,slot) SELECT ?,pair_id,1 FROM partner_invites WHERE code_hash=? AND expires_at>? AND NOT EXISTS (SELECT 1 FROM partner_members WHERE pair_id=partner_invites.pair_id AND slot=1)").bind(user.userId, codeHash, Date.now()));
  statements.push(db.prepare("DELETE FROM partner_invites WHERE code_hash=? AND EXISTS (SELECT 1 FROM partner_members WHERE user_id=? AND pair_id=partner_invites.pair_id)").bind(codeHash, user.userId));
  try { await db.batch(statements); } catch { throw new ApiError("This invitation was already used, or one account is already paired.", 409); }
  if (await partnerId(user.userId) !== invite.inviter_id) throw new ApiError("That invitation was already used. Ask your partner for a new invitation.", 409);
  await notify(invite.inviter_id, `${user.displayName} joined your private partner space.`);
}

export async function mutate(user: ChatGPTUser, input: unknown): Promise<JsonRecord> {
  const payload = object(input, "Request"); const action = text(payload.action, "Action", 50, true);
  const me = await ensureUser(user); const db = database();
  if (action === "pair.create") return createPairCode(user);
  if (action === "pair.join") await joinPair(user, payload.code);
  else if (action === "profile") {
    const next = { ...parse(me.profile), ...validateProfile(payload.profile) };
    await validatePhotoOwner(next.avatar, user.userId);
    await db.prepare("UPDATE users SET profile=? WHERE id=?").bind(JSON.stringify(next), user.userId).run();
  } else if (action === "upsert") {
    const entity = entityName(payload.entity); const table = TABLES[entity];
    const source = object(payload.record); const id = source.id ? text(source.id, "Record ID", 220, true) : crypto.randomUUID();
    const existing = await ownRecord(table, id, user.userId);
    const record = validateRecord(entity, source); await validatePhotoOwner(record.photo, user.userId);
    // Only the authenticated participant may set their manual challenge contribution.
    // Other participants' contributions remain protected even when the owner edits configuration.
    if (entity === "challenge") record.manualProgress = { [user.userId]: numeric(source.current ?? source.manualProgress?.[user.userId] ?? 0, "Your challenge contribution", 0, 100000000) };
    if (entity === "post" && record.sessionId) {
      const session = await ownRecord("sessions", record.sessionId, user.userId);
      if (!session) throw new ApiError("The selected workout is unavailable.");
    }
    const timestamp = now();
    if (entity === "step") {
      if (existing) await db.prepare("UPDATE daily_steps SET date=?,data=?,updated_at=? WHERE id=? AND user_id=?").bind(record.date, JSON.stringify(record), timestamp, id, user.userId).run();
      else await db.prepare("INSERT INTO daily_steps (id,user_id,date,data,created_at,updated_at) VALUES (?,?,?,?,?,?) ON CONFLICT(user_id,date) DO UPDATE SET data=excluded.data,updated_at=excluded.updated_at").bind(id, user.userId, record.date, JSON.stringify(record), timestamp, timestamp).run();
    } else if (entity === "challenge") {
      await db.prepare("INSERT INTO challenges (id,user_id,data,created_at,updated_at) VALUES (?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET data=json_set(excluded.data,'$.manualProgress',json_patch(COALESCE(json_extract(challenges.data,'$.manualProgress'),'{}'),json(?))),updated_at=excluded.updated_at WHERE challenges.user_id=excluded.user_id").bind(id, user.userId, JSON.stringify(record), existing?.created_at || timestamp, timestamp, JSON.stringify(record.manualProgress)).run();
    } else {
      await db.prepare(`INSERT INTO ${table} (id,user_id,data,created_at,updated_at) VALUES (?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data,updated_at=excluded.updated_at WHERE ${table}.user_id=excluded.user_id`).bind(id, user.userId, JSON.stringify(record), existing?.created_at || timestamp, timestamp).run();
    }
    if (!existing && (entity === "session" || entity === "post")) {
      const partner = await partnerId(user.userId);
      if (partner) await notify(partner, `${parse(me.profile).displayName || me.name} ${entity === "session" ? `completed ${record.name}` : `shared ${record.type === "meal" ? "a meal" : "an activity"}`}.`);
    }
  } else if (action === "challenge.progress") {
    const id = text(payload.id, "Challenge ID", 220, true);
    const contribution = numeric(payload.current, "Your challenge contribution", 0, 100000000);
    const challenge = await db.prepare("SELECT * FROM challenges WHERE id=?").bind(id).first<OwnedRow>();
    const ids = await allowedIds(user.userId);
    if (!challenge || !ids.includes(challenge.user_id)) throw new ApiError("That challenge is unavailable.", 404);
    if (parse(challenge.data).type !== "custom") throw new ApiError("This challenge updates automatically from your records.");
    // json_patch merges a single authenticated-user key within one atomic SQL update.
    // Concurrent contributions cannot overwrite each other or any challenge settings.
    await db.prepare("UPDATE challenges SET data=json_set(data,'$.manualProgress',json_patch(COALESCE(json_extract(data,'$.manualProgress'),'{}'),json(?))),updated_at=? WHERE id=?").bind(JSON.stringify({ [user.userId]: contribution }), now(), id).run();
  } else if (action === "delete") {
    const entity = entityName(payload.entity); const table = TABLES[entity]; const id = text(payload.id, "Record ID", 220, true);
    const record = await ownRecord(table, id, user.userId); if (!record) throw new ApiError("Record not found.", 404);
    const statements = [];
    if (entity === "post") {
      statements.push(db.prepare("DELETE FROM post_likes WHERE post_id=?").bind(id));
      statements.push(db.prepare("DELETE FROM post_comments WHERE post_id=?").bind(id));
      statements.push(db.prepare("DELETE FROM favorites WHERE kind='recipe' AND target_id=?").bind(id));
    }
    statements.push(db.prepare(`DELETE FROM ${table} WHERE id=? AND user_id=?`).bind(id, user.userId));
    await db.batch(statements);
  } else if (action === "like" || action === "comment") {
    const postId = text(payload.postId, "Post ID", 220, true); const post = await readablePost(postId, user.userId);
    if (action === "like") {
      const existing = await db.prepare("SELECT id FROM post_likes WHERE post_id=? AND user_id=?").bind(postId, user.userId).first<{ id: string }>();
      if (existing) await db.prepare("DELETE FROM post_likes WHERE id=? AND user_id=?").bind(existing.id, user.userId).run();
      else {
        await db.prepare("INSERT OR IGNORE INTO post_likes (id,post_id,user_id) VALUES (?,?,?)").bind(crypto.randomUUID(), postId, user.userId).run();
        if (post.user_id !== user.userId) await notify(post.user_id, `${parse(me.profile).displayName || me.name} liked your post.`);
      }
    } else {
      const comment = text(payload.text, "Comment", 3000, true);
      await db.prepare("INSERT INTO post_comments (id,post_id,user_id,text,created_at) VALUES (?,?,?,?,?)").bind(crypto.randomUUID(), postId, user.userId, comment, now()).run();
      if (post.user_id !== user.userId) await notify(post.user_id, `${parse(me.profile).displayName || me.name} commented on your post.`);
    }
  } else if (action === "comment.delete") {
    const id = text(payload.id, "Comment ID", 220, true);
    const result = await db.prepare("DELETE FROM post_comments WHERE id=? AND user_id=?").bind(id, user.userId).run();
    if (!result.meta.changes) throw new ApiError("You can only delete your own comments.", 403);
  } else if (action === "favorite") {
    const kind = payload.kind === "recipe" ? "recipe" : "exercise"; const targetId = text(payload.targetId, "Favorite", 220, true);
    if (kind === "recipe") await readablePost(targetId, user.userId);
    const existing = await db.prepare("SELECT id FROM favorites WHERE user_id=? AND kind=? AND target_id=?").bind(user.userId, kind, targetId).first<{ id: string }>();
    if (existing) await db.prepare("DELETE FROM favorites WHERE id=? AND user_id=?").bind(existing.id, user.userId).run();
    else await db.prepare("INSERT OR IGNORE INTO favorites (id,user_id,kind,target_id) VALUES (?,?,?,?)").bind(crypto.randomUUID(), user.userId, kind, targetId).run();
  } else if (action === "notifications.read") await db.prepare('UPDATE notifications SET "read"=1 WHERE user_id=?').bind(user.userId).run();
  else if (action !== "pair.join") throw new ApiError("Unknown action.");
  return snapshot(user);
}
export function errorResponse(error: unknown): Response {
  if (error instanceof ApiError) return Response.json({ error: error.message }, { status: error.status, headers: { "Cache-Control": "no-store" } });
  const message = error instanceof Error ? error.message : String(error);
  console.error("Fitness API failed:", message);
  const conflict = message.includes("UNIQUE constraint");
  return Response.json({ error: conflict ? "That record already exists. Refresh the page and try again." : "Your request could not be completed. Please try again." }, { status: conflict ? 409 : 500, headers: { "Cache-Control": "no-store" } });
}

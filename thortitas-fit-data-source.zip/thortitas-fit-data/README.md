# Thortitas Fit Data

Private, mobile-first fitness tracking for two connected partners. The app uses English, a dark interface and electric-green accents.

## Included

- ChatGPT account identity supplied by Sites; server-enforced ownership and partner read access.
- D1 database with schema migrations; R2 photos served through authenticated routes.
- 117 exercises, searchable by muscle and equipment.
- Four empty routine templates, custom categories, exercise order, working sets, target reps and notes.
- Workout logger with previous exercise performance across routines, explicit completed sets, kg, reps, RIR and manual rest. Cardio and sports logging.
- Persistent history, editing/deletion/duplication, calendar, filtering, charts and exercise records.
- Manual daily steps (one total per day), weight, progress photos, goals and shared challenges.
- Activity feed, likes, comments, meal/recipe sharing and manually entered nutrition.
- In-app notifications, private JSON/CSV exports, app manifest, icons and service worker. Online operation is required; no private responses are cached.

The initial four routines deliberately contain no invented exercise programmes. Configure them with your exact exercises before starting.

## Local development

Requirements: Node.js >=22.13, pnpm 11.25.0, Git. Run `pnpm install`, `pnpm build`, apply the pending SQL migration to local D1, then run `pnpm dev`.

The maintained Sites runtime scripts configure local D1/R2. Local development uses the starter's test identity, Seedy, only on loopback. Hosted authentication belongs to Sites; no frontend account selector exists.

The local migration command is:

```
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_nasty_moon_knight.sql
```

If Windows prevents tsx from reading the OS account, migration generation may need a local tooling fallback for `os.userInfo`. Do not change production authentication or time/expiry checks.

## Sites publication and partner access

The `.openai/hosting.json` preserves the registered private Site ID. Publish using the Sites plugin's source workflow. Keep credentials in session memory and stdin only. Neither credentials nor local database files belong in source.

To connect two people: grant the partner private visitor access in Sites, then create a pairing code under Settings and have the partner redeem it from their own ChatGPT account. Pairing does not itself change the Site's access policy. Partner invitations require the actual account email and supported native sharing controls.

## Verification status

The production build and full TypeScript check pass. The compiled Worker passed 90 local API checks covering account isolation, partner access, persistence, historical snapshots, owner-only writes, validation, step upserts, goals, concurrent challenge contributions, social/nutrition, private media and exports.

Browser QA passed: routine save/readback; workout save and persistence after reload; previous performance across different routines; explicit set completion; historical editing and recalculated analytics; one daily step entry after repeated updates; manually entered nutrition; likes, comments and recipe favorites. The same-day session chronology issue found during QA was corrected and verified: the later 528 kg session appears above the earlier 400 kg session, with +128 kg compared with the earlier result.

The dashboard, routine editor, workout logger and progress views were inspected at a 390px mobile viewport without horizontal page overflow. All synthetic records were restricted to the local database. After QA, the three synthetic accounts, all their records and media, and the browser fixtures were removed. The four original empty routines were restored, with zero foreign-key violations.

Hosted authentication with two real ChatGPT accounts, production persistence and home-screen installation require verification after private deployment succeeds. Push notifications and offline synchronization are not implemented. The current publication status is recorded in the delivered guide. No credential or expiration check is bypassed.

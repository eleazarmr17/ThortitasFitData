import { sqliteTable, text, integer, uniqueIndex, index } from "drizzle-orm/sqlite-core";

export const users = sqliteTable("users", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  profile: text("profile").notNull().default("{}"),
  createdAt: text("created_at").notNull(),
});

export const partnerMembers = sqliteTable("partner_members", {
  userId: text("user_id").primaryKey().references(() => users.id),
  pairId: text("pair_id").notNull(),
  slot: integer("slot").notNull(),
}, t => [uniqueIndex("partner_pair_slot").on(t.pairId, t.slot)]);

export const partnerInvites = sqliteTable("partner_invites", {
  codeHash: text("code_hash").primaryKey(),
  pairId: text("pair_id").notNull(),
  inviterId: text("inviter_id").notNull().references(() => users.id),
  expiresAt: integer("expires_at").notNull(),
}, t => [uniqueIndex("partner_inviter").on(t.inviterId)]);

const ownedColumns = () => ({
  id: text("id").primaryKey(), userId: text("user_id").notNull().references(() => users.id),
  data: text("data").notNull(), createdAt: text("created_at").notNull(), updatedAt: text("updated_at").notNull(),
});
export const routines = sqliteTable("routines", ownedColumns(), t => [index("routine_owner").on(t.userId)]);
export const sessions = sqliteTable("sessions", ownedColumns(), t => [index("session_owner").on(t.userId)]);
export const dailySteps = sqliteTable("daily_steps", { ...ownedColumns(), date: text("date").notNull() }, t => [uniqueIndex("step_owner_date").on(t.userId, t.date)]);
export const bodyWeights = sqliteTable("body_weights", ownedColumns(), t => [index("weight_owner").on(t.userId)]);
export const goals = sqliteTable("goals", ownedColumns(), t => [index("goal_owner").on(t.userId)]);
export const challenges = sqliteTable("challenges", ownedColumns(), t => [index("challenge_owner").on(t.userId)]);
export const posts = sqliteTable("posts", ownedColumns(), t => [index("post_owner").on(t.userId)]);

export const postLikes = sqliteTable("post_likes", {
  id: text("id").primaryKey(), postId: text("post_id").notNull().references(() => posts.id, { onDelete: "cascade" }), userId: text("user_id").notNull().references(() => users.id),
}, t => [uniqueIndex("like_post_user").on(t.postId, t.userId)]);
export const postComments = sqliteTable("post_comments", {
  id: text("id").primaryKey(), postId: text("post_id").notNull().references(() => posts.id, { onDelete: "cascade" }),
  userId: text("user_id").notNull().references(() => users.id), text: text("text").notNull(), createdAt: text("created_at").notNull(),
}, t => [index("comment_post").on(t.postId)]);
export const favorites = sqliteTable("favorites", {
  id: text("id").primaryKey(), userId: text("user_id").notNull().references(() => users.id), kind: text("kind").notNull(), targetId: text("target_id").notNull(),
}, t => [uniqueIndex("favorite_user_target").on(t.userId, t.kind, t.targetId)]);
export const notifications = sqliteTable("notifications", {
  id: text("id").primaryKey(), userId: text("user_id").notNull().references(() => users.id), text: text("text").notNull(),
  read: integer("read").notNull().default(0), createdAt: text("created_at").notNull(),
}, t => [index("notification_owner").on(t.userId)]);
export const media = sqliteTable("media", {
  key: text("key").primaryKey(), userId: text("user_id").notNull().references(() => users.id),
  contentType: text("content_type").notNull(), createdAt: text("created_at").notNull(),
}, t => [index("media_owner").on(t.userId)]);

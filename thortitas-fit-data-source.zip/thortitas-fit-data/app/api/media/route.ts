import { env } from "cloudflare:workers";
import { allowedIds, authenticated, boundedBody, checkWriteOrigin, database, ensureUser, errorResponse } from "../../../lib/server-data";
import { ApiError } from "../../../lib/server-validation";
export const dynamic = "force-dynamic";
const MAX_SIZE = 8 * 1024 * 1024;
function identify(bytes: Uint8Array): string | null {
  if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return "image/jpeg";
  if ([137,80,78,71,13,10,26,10].every((n, i) => bytes[i] === n)) return "image/png";
  if (String.fromCharCode(...bytes.slice(0, 6)) === "GIF87a" || String.fromCharCode(...bytes.slice(0, 6)) === "GIF89a") return "image/gif";
  if (String.fromCharCode(...bytes.slice(0, 4)) === "RIFF" && String.fromCharCode(...bytes.slice(8, 12)) === "WEBP") return "image/webp";
  return null;
}
export async function POST(request: Request) {
  try {
    checkWriteOrigin(request); const user = await authenticated(); await ensureUser(user);
    if (!env.BUCKET) throw new ApiError("Photo storage is temporarily unavailable.", 503);
    const body = await boundedBody(request, MAX_SIZE + 65536);
    const form = await new Response(body, { headers: { "Content-Type": request.headers.get("content-type") || "" } }).formData(); const file = form.get("file");
    if (!file || typeof file === "string" || !file.size || file.size > MAX_SIZE) throw new ApiError("Choose a photo smaller than 8 MB.");
    const bytes = new Uint8Array(await file.arrayBuffer()); const contentType = identify(bytes);
    if (!contentType) throw new ApiError("Choose a JPEG, PNG, WebP or GIF photo.");
    const key = crypto.randomUUID();
    await env.BUCKET.put(key, bytes, { httpMetadata: { contentType, cacheControl: "private, max-age=120" } });
    try { await database().prepare("INSERT INTO media (key,user_id,content_type,created_at) VALUES (?,?,?,?)").bind(key, user.userId, contentType, new Date().toISOString()).run(); }
    catch (error) { await env.BUCKET.delete(key); throw error; }
    return Response.json({ key, url: `/api/media?key=${encodeURIComponent(key)}` }, { status: 201, headers: { "Cache-Control": "no-store" } });
  } catch (error) { return errorResponse(error); }
}
export async function GET(request: Request) {
  try {
    const user = await authenticated(); const key = new URL(request.url).searchParams.get("key");
    if (!key || !/^[a-zA-Z0-9-]{36}$/.test(key)) throw new ApiError("Photo not found.", 404);
    const record = await database().prepare("SELECT user_id,content_type FROM media WHERE key=?").bind(key).first<{ user_id: string; content_type: string }>();
    if (!record || !(await allowedIds(user.userId)).includes(record.user_id)) throw new ApiError("Photo not found.", 404);
    if (!env.BUCKET) throw new ApiError("Photo storage is temporarily unavailable.", 503);
    const file = await env.BUCKET.get(key); if (!file) throw new ApiError("Photo not found.", 404);
    return new Response(file.body, { headers: { "Content-Type": record.content_type, "Content-Disposition": "inline", "X-Content-Type-Options": "nosniff", "Cache-Control": "private, max-age=120", "Vary": "Cookie", "Content-Security-Policy": "default-src 'none'" } });
  } catch (error) { return errorResponse(error); }
}
